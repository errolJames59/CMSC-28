#include <iostream>
#include <string>
#include "Student.h"

void description(){
    std::cout << "-------------------------------------------------" << endl;
    std::cout << "This is a program made for student registration.\nThe program will ask for the student's information\nand display the information entered." << endl;
    std::cout << "Developed by: \n\tErrol James B. Minguez\n\t1 - BSCS\n\nFor:\n\tComputer Science 28 [Lab 8]" << endl;
    std::cout << "-------------------------------------------------" << endl;
}

int main(){
    description();
    string fname, lname, course, department, college, email, studentNum, phoneNum;
    char gender;
    int age;
    bool m;
    Student s;

    std::cout << "-------------------------------------------------" << endl;
    std::cout << "\t\tSTUDENT INFORMATION" << endl;

    std::cout << "\nFirst name: ";
    std::getline(std::cin, fname);
    s.p.setFname(fname);

    std::cout << "Last name: ";
    std::getline(std::cin, lname);
    s.p.setLname(lname);

    std::cout << "Age: ";
    std::cin >> age;
    s.p.setage(age);

    do {
        std::cout << "Gender [M/F]: ";
        std::cin >> gender;
        s.p.setgender(gender);
    } while (gender != 'M' && gender != 'F' && gender != 'm' && gender != 'f');

    do {
        std::cout << "Email address: ";
        std::cin >> email;
        m = s.p.setEmail(email);
    } while (!m);

    do {
        std::cout << "Phone number: ";
        std::cin >> phoneNum;
        m = s.p.setphone(phoneNum);
    }while(!m);

    do {
        std::cout << "Student Number (2022-12345): ";
        std::cin >> studentNum;
        std::cin.ignore();
        s.setStudentNum(studentNum);
    } while (!m);


    std::cout << "Course: ";
    std::getline(std::cin, course);
    s.setCourse(course);

    std::cout << "Department: ";
    std::getline(std::cin, department);
    s.setDep(department);

    std::cout << "College: ";
    std::getline(std::cin, college);
    s.setCollege(college);

    s.view();
    return 0;
}