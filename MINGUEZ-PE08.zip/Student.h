#include <iostream>
#include <regex>
#include "Person.h"

class Student: public Person {
    private: 
        string studentNum;

    public:
        Person p;
        string course;
        string department;
        string college;

        bool setStudentNum(string k){
                if (isValidStudentNum(k)){
                    studentNum = k;
                    return true;
                } else {
                    cout << "Invalid student number!" << endl;
                    return false;
                }
            }

        bool isValidStudentNum(const string& num) {
            const regex pattern(R"(^\d{4}-\d{5}$)");

            return regex_match(num, pattern);
        }

        string viewStudentNum(){
            return studentNum;
        }

        void setCourse(string c){
            course = c;
        }

        void setDep(string d){
            department = d;
        }

        void setCollege(string c){
            college = c;
        }

        void view(){
            std::cout << "\n\n-------------------------------------------------" << endl;
            std::cout << "STUDENT INFORMATION" << endl;
            std::cout << "\nFirst name: \t"<< p.getFname() << endl;
            std::cout << "Last name: \t"<< p.getLname() << endl;
            std::cout << "Age: \t\t" << p.getage() << endl;
            std::cout << "Gender: \t" << p.getgender() << endl;
            std::cout << "Email address: \t" << p.emailAdd << endl;
            std::cout << "Phone number: \t" << p.getPhone()  << endl;
            std::cout << "Student Number: " << studentNum << endl;
            std::cout << "Course: \t" << course << endl;
            std::cout << "Department: \t" << department << endl;
            std::cout << "College: \t" << college << endl;
            std::cout << "-------------------------------------------------\n" << endl;

            std::cout << "Hi, " << p.getFname() + " " + p.getLname() <<  " Welcome to UP Mindanao and\ncongratulations! We are pleased to inform you that you \nare admitted in the " << course << " program under the \n" << department << ", " << college << ". Your Student number is " << viewStudentNum() << endl; 
            std::cout << "-------------------------------------------------\n\n\n" << endl; 
        }
};