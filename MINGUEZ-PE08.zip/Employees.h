#include <iostream> 
#include "Person.h"

class Employees: public Person {
    private: 
        string empNum;
    public:
        Person p;
        string position, office;
        float salary;

        void setEmployeeNum(string e){
            empNum = e;
        }
        
        string getEmployeeNum(){
            return empNum;
        }

        void view(){
            std::cout << "\n\n-------------------------------------------------" << endl;
            std::cout << "EMPLOYEE INFORMATION" << endl;
            std::cout << "\nFirst name: \t"<< p.getFname() << endl;
            std::cout << "Last name: \t"<< p.getLname() << endl;
            std::cout << "Age: \t\t" << p.getage() << endl;
            std::cout << "Gender: \t" << p.getgender() << endl;
            std::cout << "Email address: \t" << p.emailAdd << endl;
            std::cout << "Phone number: \t" << p.getPhone()  << endl;
            std::cout << "Employee Number: " << getEmployeeNum() << endl;
            std::cout << "Position: \t" << position << endl;
            std::cout << "Office/Unit: \t" << office << endl;
            std::cout << "Salary: \t" << salary << endl;
            std::cout << "-------------------------------------------------\n" << endl; 
        }

};