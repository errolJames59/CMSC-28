#include <iostream>
#include <regex>
using namespace std;
class Person
{
private:
    int age;
    char gender;
    string fname, lname;

public:
    Person() {}
    string emailAdd, cpNumber;

    bool setEmail(string e){
        if (isValidEmail(e)) {
            emailAdd = e;
            return true;
        } else {
            cout << "Enter valid email address!" << endl;
            return false;
        }
    }

    bool setphone(string n){
        const regex pattern(R"(^\d{11}$)");
        if (regex_match(n, pattern)){
            cpNumber = n;
            return true;
        } else {
            cout << "Enter valid phone number!" << endl;
            return false;
        }
    }

    string getPhone(){
        return cpNumber;
    }

    // seaeched for email validation code
    bool isValidEmail(const string& email) {
        // Define the regular expression for a valid email address
        const regex pattern(R"((\w+)(\.|\-)?(\w*)@(\w+)(\.(\w+))+)");
        
        // Try to match the string with the regular expression
        return regex_match(email, pattern);
    }

    void setFname(string f){
        fname = f;
    }

    void setLname(string l){
        lname = l;
    }

    string getFname(){
        return fname;
    }

    string getLname(){
        return lname;
    }

    Person(int newage){
        age = newage;
        gender = 'M';
    }

    Person(int newage, char c){
        age = newage;
        gender = c;
    }

    void setage(int newage){
        if (newage >= 0){
            age = newage;
        } else {
            cout << "invalid age!!!" << endl;
        }
    }

    int getage()
    {
        return age;
    }

    void setgender(char c){
        if ((c == 'M') || (c == 'F') || (c == 'f') || (c == 'm')){
            gender = c;
        } else {
            cout << "invalid input!" << endl;
        }
    }

    char getgender(){
        return gender;
    }

    void view(){
        cout << "Person age is    = " << getage() << endl;
        cout << "Person gender is = " << getgender() << endl;
    }

    void view(int age){
        cout << "Person age is    = " << getage() << endl;
        cout << "Person gender is = " << getgender() << endl;
    }

    void view(int age, char gender){
        cout << "Person age is    = " << age << endl;
        cout << "Person gender is = " << gender << endl;
    }
};