#include <iostream>
#include <string>
#include "ProductInventory.h"

using namespace std;

int main() { // variable declarations
    string name, brand, description, color, category, model, techSpecs, material, size;
    float price, warranty;
    int quantity, choice, choice2;
    Clothing c;
    Electronics e;

// do-while loop to add product until the user inputs 0 to exit the program
    do {
        cout << "----------Product Inventory----------" << endl;
        cout << "Enter category: \n\t[1] Clothing\n\t[2] Electronics\n\tChoice: ";
        cin >> choice2;

        if (choice2 == 1) { // Input clothing product details
            cout << "\n\tName: ";
            cin.ignore();
            getline(cin, name);
            c.setName(name);

            cout << "\tBrand: ";
            getline(cin, brand);
            c.setBrand(brand);

            cout << "\tPrice: ";
            cin >> price;
            c.setPrice(price);

            cout << "\tQuantity: ";
            cin >> quantity;
            c.setQuantity(quantity);

            cout << "\tDescription: ";
            cin.ignore();
            getline(cin, description);
            c.setDesc(description);

            cout << "\tSize: ";
            getline(cin, size);
            c.setSize(size);

            cout << "\tColor: ";
            getline(cin, color);
            c.setColor(color);

            cout << "\tCategory: ";
            getline(cin, category);
            c.setCateg(category);

            cout << "\tModel: ";
            getline(cin, model);
            c.setModel(model);

            cout << "\tWarranty (months): ";
            cin >> warranty;
            c.setWarranty(warranty);

            c.setTechSpecs("N/A");

            cout << "\tMaterial: ";
            cin.ignore();
            getline(cin, material);
            c.setMaterial(material);

        } else { // Input electronic product details
            cout << "\n\tName: ";
            cin.ignore();
            getline(cin, name);
            e.setName(name);

            cout << "\tBrand: ";
            getline(cin, brand);
            e.setBrand(brand);

            cout << "\tPrice: ";
            cin >> price;
            e.setPrice(price);

            cout << "\tQuantity: ";
            cin >> quantity;
            e.setQuantity(quantity);

            cout << "\tDescription: ";
            cin.ignore();
            getline(cin, description);
            e.setDesc(description);

            cout << "\tSize: ";
            getline(cin, size);
            e.setSize(size);

            cout << "\tColor: ";
            getline(cin, color);
            e.setColor(color);

            cout << "\tCategory: ";
            getline(cin, category);
            e.setCateg(category);

            cout << "\tModel: ";
            getline(cin, model);
            e.setModel(model);

            cout << "\tWarranty (months): ";
            cin >> warranty;
            e.setWarranty(warranty);

            cout << "\tTechnical Specs: ";
            cin.ignore();
            getline(cin, techSpecs);
            e.setTechSpecs(techSpecs);

            cout << "\tMaterial: ";
            getline(cin, material);
            e.setMaterial(material);
        }
// Add another product
        cout << "Add another product: \n\t[1] Yes\n\t[0] No\n\tChoice: ";
        cin >> choice;

    } while (choice != 0);

// Print all product details
    cout << "\n\n----------Product Inventory----------" << endl;
    cout << "---------------CLOTHING--------------" << endl;
    c.viewProd1(); // call viewprod1 from class clothing
    cout << "\n";
    cout << "-------------------------------------\n\n" << endl;

    cout << "----------Product Inventory----------" << endl;
    cout << "--------------ELECTRONICS------------" << endl;
    e.viewProd1(); // call viewprod1 from class electronics
    cout << "\n";
    cout << "-------------------------------------" << endl;

    return 0;
}
