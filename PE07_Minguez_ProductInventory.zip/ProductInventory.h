#include <iostream>
#include <string>
#include <list> // use the list library
using namespace std;

class Product {
protected:
    list <string> name;
    list <string> brand;
    list <float> price;
    list <int> quantity;
    list <string> description;
    list <string> size;
    list <string> color;
    list <string> category;
    list <string> model;
    list <float> warranty;
    list <string> techSpecs;
    list <string> material;
public:
    // Setters
    // using push_back() to push values to the lists
    void setName(string n){
        name.push_back(n);
    }
    void setBrand(string b){
        brand.push_back(b);
    }
    void setPrice(float p){
        price.push_back(p);
    }
    void setQuantity(int q){
        quantity.push_back(q);
    }
    void setDesc(string d){
        description.push_back(d);
    }
    void setSize(string s){
        size.push_back(s);
    }
    void setColor(string c){
        color.push_back(c);
    }
    void setCateg(string cat){
        category.push_back(cat);
    }
    void setModel(string m){
        model.push_back(m);
    }
    void setWarranty(float w){
        warranty.push_back(w);
    }
    void setTechSpecs(string tech){
        techSpecs.push_back(tech);
    }
    void setMaterial(string mats){
        material.push_back(mats);
    }

// function to view product details by traversing the list
// the while loop traverses the list until the list ends
    void viewProd1() {
        auto i1 = name.begin();
        auto i2 = brand.begin();
        auto i3 = price.begin();
        auto i4 = quantity.begin();
        auto i5 = description.begin();
        auto i6 = size.begin();
        auto i7 = color.begin();
        auto i8 = category.begin();
        auto i9 = model.begin();
        auto i10 = warranty.begin();
        auto i11 = techSpecs.begin();
        auto i12 = material.begin();

        while (i1 != name.end() && i2 != brand.end() && i3 != price.end() && i4 != quantity.end() && i5 != description.end()
            && i6 != size.end() && i7 != color.end() && i8 != category.end() && i9 != model.end() && i10 != warranty.end()
            && i11 != techSpecs.end() && i12 != material.end()) {
            cout << "Name: " << *i1 << endl;
            cout << "Brand: " << *i2 << endl;
            cout << "Price: " << *i3 << endl;
            cout << "Quantity: " << *i4 << endl;
            cout << "Description: " << *i5 << endl;
            cout << "Size: " << *i6 << endl;
            cout << "Color: " << *i7 << endl;
            cout << "Category: " << *i8 << endl;
            cout << "Model: " << *i9 << endl;
            cout << "Warranty (months): " << *i10 << endl;
            cout << "Technical Specs: " << *i11 << endl;
            cout << "Material: " << *i12 << endl;
            cout << "-------------------------------------\n\n";

            ++i1;
            ++i2;
            ++i3;
            ++i4;
            ++i5;
            ++i6;
            ++i7;
            ++i8;
            ++i9;
            ++i10;
            ++i11;
            ++i12;
        }
    }
};

// class clothing inhereting product class attributes
class Clothing: public Product {
};
// class electronics inhereting product class attributes
class Electronics: public Product {
};