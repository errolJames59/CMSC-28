#include <iostream>
using namespace std;
// Class definition
class Book {
private: // Private attributes
    string title;
    string author;
    string isbn;
    string publisher;
public:
    // Constructor [default]
    Book(){}
    // Constructor accepting title parameter
    Book(string ti){
        title = "[" + ti + "]";
        author = "Sample Author";
        isbn = "Sample ISBN";
        publisher = "Sample Publisher";
    }
    // Constructor accepting title, author parameters
    Book(string ti, string au){
        title = "[" + ti + "]";
        author = "[" + au + "]";
        isbn = "Sample ISBN";
        publisher = "Sample Publisher";
    }
    // Constructor accepting title, author, isbn parameters
    Book(string ti, string au, string is){
        title = "[" + ti + "]";
        author = "[" + au + "]";
        isbn = "[" + is + "]";
        publisher = "Sample Publisher";
    }
    // Constructor accepting all parameters
    Book(string ti, string au, string is, string pub){
        title = "[" + ti + "]";
        author = "[" + au + "]";
        isbn = "[" + is + "]";
        publisher = "[" + pub + "]";
    }

    // Getters
    string getTitle(){
        return title;
    }
    string getAuthor(){
        return author;
    }
    string getISBN(){
        return isbn;
    }
    string getPublisher(){
        return publisher;
    }

    // Setters
    void setTitle(string bktitle){
        title = bktitle;
    }
    void setAuthor(string bkauthor){
        author = bkauthor;
    }
    void setISBN(string bkisbn){
        isbn = bkisbn;
    }
    void setPublisher(string bkpublisher){
        publisher = bkpublisher;
    }

    void viewbook(){
            cout << "\n\n=================================================" << endl;
                cout << "Title: \t\t" << getTitle() << endl;
                cout << "Author: \t" << getAuthor() << endl;
                cout << "ISBN: \t\t" << getISBN() << endl;
                cout << "Publisher: \t" << getPublisher() << endl;
            cout << "=================================================" << endl;
    }
};