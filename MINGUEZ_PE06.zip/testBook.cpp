// MINGUEZ, Errol James
// CMSC 28 - UML DIAGRAM OF CLASS
#include <iostream> 
#include <string> 
#include "Book.h"
using namespace std;
// Description: This program demonstrates the use of the Book class.
int description(){
    int choice;
    cout << "\n\n=========================================================\nfegf" << endl;
    cout << "\tSubmitted by: Errol James Minguez" << endl;
    cout << "\t  CMSC 28 - UML DIAGRAM OF CLASS" << endl;
    cout << "\n=========================================================" << endl;
    cout << "[1] Create book1 object using 1st Constructor (no parameter)" << endl;
    cout << "[2] Create book2 object using 2nd Constructor (title only)" << endl;
    cout << "[3] Create book3 object using 3rd Constructor (ti, au only)" << endl;
    cout << "[4] Create book4 object using 4th Constructor (ti, au, is only)" << endl;
    cout << "[5] Create book5 object using 5th Constructor (all parameters)" << endl;
    cout << "[0] Exit Program" << endl;
    cout << "Input choice: ";
    cin >> choice;
    cout << "\n=========================================================\n\n" << endl;
    return choice;
}
// Main function
int main(){
    Book book;
    string ti, au, is, pub;
    int choice;
    system("cls");

    // User input
    cout << "Input title: ";
    getline(cin, ti);
    book.setTitle(ti);
    cout << "Input author: ";
    getline(cin, au);
    book.setAuthor(au);
    cout << "Input isbn: ";
    getline(cin, is);
    book.setISBN(is);
    cout << "Input publisher: ";
    getline(cin, pub);
    book.setPublisher(pub);

    // Menu
    do { 
    choice = description();
    switch (choice) {
        case 1: // Create book1 object using 1st Constructor (no parameter)
                book.viewbook();
                break;
        case 2: // Create book2 object using 2nd Constructor (title only)
            {
                Book book1(ti); 
                book1.viewbook();
            }
            break;
        case 3: // Create book3 object using 3rd Constructor (ti, au only)
            {
                Book book2(ti, au); 
                book2.viewbook();
            }
            break;
        case 4: // Create book4 object using 4th Constructor (ti, au, is only)
            {
                Book book3(ti, au, is); 
                book3.viewbook();
            }
            break;
        case 5: // Create book5 object using 5th Constructor (all parameters)
            {
                Book book4(ti, au, is, pub); 
                book4.viewbook();
            }
            break;
        case 0: // Exit Program
            cout << "=================================================" << endl;
            cout << "\tThank you for using my program!" << endl;
            cout << "=================================================" << endl;
            break;
        default:
            cout << "Invalid choice! Please try again.\n" << endl;
            break;
    }
    } while (choice != 0); // End of do-while loop

    return 0;
}