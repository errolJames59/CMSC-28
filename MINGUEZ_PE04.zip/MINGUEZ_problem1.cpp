/* 
    ERROL JAMES B. MINGUEZ - 2023-13990
    BSCS - I
    This is a program asks the user to input three numbers (x, y, z), and find the highest and lowest number, and output their difference. 
*/

#include <iostream> 
using namespace std;

void description(){
    cout << "====================================" << endl;
    cout << "Developed by: Errol James B. Minguez" << endl;
    cout << "====================================" << endl;
    cout << "This program asks the user to input " << endl;
    cout << "three numbers (x, y, z), and find the " << endl;
    cout << "highest and lowest number, and output " << endl;
    cout << "their difference." << endl;
    cout << "====================================" << endl;
}

// Function to find the highest number
float findMax(float num1, float num2, float num3) {
    if (num1 > num2 && num1 > num3) {
        return num1;
    } else if (num2 > num1 && num2 > num3) {
        return num2;
    } else {
        return num3;
    }
}

// Function to find the lowest number
float findLow(float num1, float num2, float num3) {
    if (num1 < num2 && num1 < num3) {
        return num1;
    } else if (num2 < num1 && num2 < num3) {
        return num2;
    } else {
        return num3;
    }
}

// Main function
int main() {
    float num1, num2, num3, max, min, difference; // Declare variables
    description();
    cout << "Put space between the numbers. Ex. 1 2 3\n";
    cout << "Input num1, num2, num3 = ";
    cin >> num1 >> num2 >> num3; // Input the three numbers
    cout << "Numbers inputted:\n";
    cout << "num1: " << num1 << " num2: " << num2 << " num3: " << num3 << endl; // Output the three numbers
    max = findMax(num1, num2, num3);
    cout << "Highest number: " << max << endl;
    min = findLow(num1, num2, num3);
    cout << "Lowest number: " << min << endl;
    difference = max - min; // Find the difference between the highest and lowest number    
    cout << "The difference between the highest and lowest number is: " << difference << endl; // Output the difference
    return 0;
}