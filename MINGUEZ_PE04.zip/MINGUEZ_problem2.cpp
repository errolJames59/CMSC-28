/* 
    ERROL JAMES B. MINGUEZ - 2023-13990
    BSCS - I
    This is a program that asks the user to input an integer and convert this number to its binary equivalent.
*/

#include <iostream>
using namespace std;

void description(){
    cout << "====================================" << endl;
    cout << "Developed by: Errol James B. Minguez" << endl;
    cout << "====================================" << endl;
    cout << "This program asks the user to input " << endl;
    cout << "an integer and convert it to its " << endl;
    cout << "binary equivalent." << endl;
    cout << "====================================" << endl;
}

// Function to convert decimal to binary
void toBinary(int num) {
    int temp = num, i = 0, j;
    int binary[50];
    while (num > 0) {
        binary[i] = num % 2; // store the remained in the array
        num = num/2; // divide the number by 2
        i++; // increment i
    }

    cout << "Binary equivalent of " << temp << " is : ";

    // Display the binary equivalent using for loop, and decrementing j to display the number in reverse
    for (j = i-1; j>= 0; j--) {
        cout << binary[j];
    }
}

// Main function
int main() {
    int num, binary[100];
    description();
    cout << "Input number: ";
    cin >> num;
    toBinary(num);
    return 0;
}